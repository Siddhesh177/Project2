/* 
 * CardCheck.java 
 * 
 * Version: 
 *     Id$ 1.0
 *
 */
 /*
 * This class is used to make the function return two striing altogether within the 
 * client(ImagePanel) side.
 * This is having two attributes as string which is getting the value through the constructor  
 *  
 * @authors :   Siddhesh Periaswami , Shubham Malhotra , Joe Chenn
 * Final Project
 * Class ISTE 121
 */



import java.util.*; // package


public class CardCheck{ 
String first; // local variables
String second; // local variables

public CardCheck(String first,String second){
   this.first = first; // setting the first arg value equal to first of local variable of class
   this.second = second; // setting the second arg value equal to second of local variable of class

}
}